import sys
print("Congrats! You finished the (pre-pre-pre-alpha from during development) demo (AKA the only levels of this game I guess)")
sys.exit()